require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const ExcelJS = require('exceljs');
const Service = require('./models/Service');
const ServiceHistory = require('./models/ServiceHistory');
const Category = require('./models/Category');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Multer
const storage = multer.diskStorage({
  destination: (_, __, cb) => {
    const dir = path.join(__dirname, '..', 'uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (_, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const fileFilter = (_, file, cb) => cb(null, /jpe?g|png|gif|webp/i.test(file.originalname));
const upload = multer({ storage, fileFilter });

// Routes
const categoryRoutes = require('./routes/categories');
app.use('/api/categories', categoryRoutes);

/* --- Service CRUD --- */
app.get('/api/services', async (req, res) => {
  const { status = 'published' } = req.query;
  const filter = status === 'all' ? {} : { status };
  const services = await Service.find(filter)
    .populate('category', 'name')
    .sort({ order: 1, createdAt: -1 });
  res.json(services);
});

app.post('/api/services', upload.array('images', 5), async (req, res) => {
  try {
    const { title, description, price, category } = req.body;
    if (!mongoose.Types.ObjectId.isValid(category))
      return res.status(400).json({ error: 'Неверный ID категории' });

    const images = (req.files || []).map(f => `/uploads/${f.filename}`);
    const service = new Service({ title, description, price: Number(price), category, images });
    await service.save();
    res.status(201).json(service);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/services/:id', upload.array('images', 5), async (req, res) => {
  try {
    const { title, description, price, category } = req.body;
    if (!mongoose.Types.ObjectId.isValid(category))
      return res.status(400).json({ error: 'Неверный ID категории' });

    const images = req.files?.map(f => `/uploads/${f.filename}`);
    const update = { title, description, price: Number(price), category };
    if (images?.length) update.images = images;

    const old = await Service.findById(req.params.id);
    const updated = await Service.findByIdAndUpdate(req.params.id, update, { new: true }).populate('category', 'name');

    // Audit log
    ['title', 'description', 'price', 'status'].forEach((f) => {
      if (old[f] !== update[f]) {
        ServiceHistory.create({ serviceId: old._id, field: f, oldVal: old[f], newVal: update[f] });
      }
    });

    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/services/:id', async (req, res) => {
  await Service.findByIdAndDelete(req.params.id);
  res.json({ message: 'Удалено' });
});

/* --- Bulk actions --- */
app.patch('/api/services/bulk', async (req, res) => {
  try {
    const { ids, action } = req.body;
    if (!Array.isArray(ids)) return res.status(400).json({ error: 'ids must be array' });

    switch (action) {
      case 'delete':
        await Service.deleteMany({ _id: { $in: ids } });
        break;
      case 'publish':
        await Service.updateMany({ _id: { $in: ids } }, { status: 'published' });
        break;
      case 'draft':
        await Service.updateMany({ _id: { $in: ids } }, { status: 'draft' });
        break;
      default:
        return res.status(400).json({ error: 'unknown action' });
    }
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/* --- Sort order --- */
app.patch('/api/services/sort', async (req, res) => {
  try {
    const { items } = req.body; // [{ id, order }]
    for (const { id, order } of items) {
      await Service.findByIdAndUpdate(id, { order });
    }
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

/* --- Audit log --- */
app.get('/api/services/:id/history', async (req, res) => {
  const logs = await ServiceHistory.find({ serviceId: req.params.id }).sort({ createdAt: -1 });
  res.json(logs);
});

/* --- Excel export --- */
app.get('/api/services/export/xlsx', async (_, res) => {
  const services = await Service.find().populate('category', 'name').sort({ order: 1 });
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Price');
  ws.columns = [
    { header: 'Название', key: 'title', width: 30 },
    { header: 'Категория', key: 'category', width: 20 },
    { header: 'Цена', key: 'price', width: 10 },
    { header: 'Статус', key: 'status', width: 10 },
  ];
  services.forEach((s) => ws.addRow({ title: s.title, category: s.category.name, price: s.price, status: s.status }));
  res.setHeader('Content-Disposition', 'attachment; filename=price.xlsx');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  await wb.xlsx.write(res);
});

/* --- MongoDB --- */
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  });

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));